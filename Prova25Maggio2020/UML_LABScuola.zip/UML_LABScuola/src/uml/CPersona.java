/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uml;

/**
 *
 * @author Prof
 */
public class CPersona {
    String  nome;
    CDate   dataNascita;
	CHardware[] hardware;
	
	void richiediAutorizzazione(CDate data1, Cdate scadenza);
}
