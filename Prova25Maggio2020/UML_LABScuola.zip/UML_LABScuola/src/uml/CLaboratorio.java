/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uml;

/**
 *
 * @author Prof
 */
public class CLaboratorio {
    int       siglaIdentificativa;
    String    nome;
    String    descrizione;
    String    edificio;
    int       piano;
}
